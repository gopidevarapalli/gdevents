export default Images = [
  {
    id: 1,
    url: "https://events.globaldata.com/wp-content/uploads/2020/12/booth-image-2.jpg",
  },
  {
    id: 2,
    url: "https://events.globaldata.com/wp-content/uploads/2021/01/13-1.jpg",
  },
  {
    id: 3,
    url: "https://events.globaldata.com/wp-content/uploads/2020/12/booth-image-1.jpg",
  },
  {
    id: 4,
    url: "https://events.globaldata.com/wp-content/uploads/2020/12/booth-image-3.jpg",
  },
];
