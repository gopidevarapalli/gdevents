export default Videos = [
  {
    id: 1,
    url: "https://www.youtube.com/embed/VIkm6nIBoM0",
  },
  {
    id: 2,
    url: "https://www.youtube.com/embed/r6YtHPvyJNk",
  },
];
