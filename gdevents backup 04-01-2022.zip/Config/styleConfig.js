const styleConfig = {
  mT10: 10,
  mT20: 20,
  mVT10: 10,
 
};

export default styleConfig;
