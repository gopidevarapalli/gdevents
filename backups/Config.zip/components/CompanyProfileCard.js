import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  
} from 'react-native';
import {useTheme} from '@react-navigation/native';
import { Button } from 'react-native-paper';
const CompanyProfileCard = (props) => {
  const theme = useTheme();
//   console.log(Stats)
// console.log(17)
// console.log(props.CompanyProfile)

  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle={theme.dark ? 'light-content' : 'dark-content'} />
     
      <View  style={{width:'100%',padding:10}}>
      
          {props.CompanyProfile.map((company,i)=> <View key={i}>
          <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex:1}}>
                <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Company Name </Text>
                </View>
                <View style={{ flex: 1,paddingTop:5,paddingBottom:5,fontSize:20}}>
                    <Text style={{lineHeight:54,fontSize:16,fontWeight:'600'}}>{company.companyname}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Company Bio</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.companybio}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Company Type</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Companytype}</Text>
                </View>
            </View>

            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Company 
                    Classifications</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Companyclassifications}</Text>
                </View>
            </View>

            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Website</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Website}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Address</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Address}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Address</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Address}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Booth Number</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Boothnumber}</Text>
                </View>
            </View>
            <View style={{flexDirection: "column",flex: 1, padding: 2,justifyContent: "space-around"}}>
                <View style={{flex: 1,paddingBottom:5}}>
                    <Text style={{color:'#09BA90',fontWeight:'bold',fontSize:18,lineHeight:24}}>Premium</Text>
                </View>
                <View style={{ flex: 1}}>
                    <Text style={{lineHeight:24,fontSize:15}}>{company.Premium}</Text>
                </View>
            </View>
            
          
          </View>
          )}
         </View>
    </ScrollView>
  );
};

export default CompanyProfileCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardsWrapper: {
    marginTop: 10,
    marginBottom:10,
    width: '90%',
    alignSelf: 'center',
  },
 
});
