import React, {useEffect, useState} from 'react';
import {View, SafeAreaView, StyleSheet, ActivityIndicator, Image, Alert, Dimensions} from 'react-native';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import {
  Avatar,
  Title,
  Caption,
  Text,
  TouchableRipple,
} from 'react-native-paper';
import HTML from 'react-native-render-html';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
 

import { connect } from 'react-redux';

import IonIcon from 'react-native-vector-icons/Ionicons';

// import {GetUserInfoAction} from '../redux/action/actions';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import store from '../redux/store';
import Axios from 'axios';
import api_url from '../Config/Config';

  
const UserDetailsCard = (props) => {

  const navigation = useNavigation();

  const [Profile, setProfile] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [bookmarkLoad,setBookmarkLoad] = useState(false);
  

  // if(isLoading){  
  //   props.GetUserInfoAction(props.login.cookie, props.route.params.user_id);
  // }


  useEffect(()=>{ 
    
    let formData = new FormData(); 
    formData.append('cookie',props.login.cookie); 
    formData.append('user_id',props.user_id); 

    axios
      .post(`${api_url.userDetails}`, formData)
      .then(res =>{
        // console.log(res.data)
        // console.log(res.data)
        setProfile([res.data.aboutuser]);
        setIsLoading(false);

      })
 
  },[props.user_id]);


  const bookmark = (company)=>{ 
    
    const formData = new FormData();
    formData.append('cookie',store.getState().login.cookie);
    formData.append('bookmarktype','attendees');
    formData.append('status',company.user_bookmark_status?0:1);
    formData.append('title',company.firstname);
    formData.append('id',props.user_id);
    // console.log(company)
    Axios.post(`${api_url.bookmark}`, formData)
    .then(res=>{
      // console.log(res.data);
        if(res.data.status === "ok"){
          Alert.alert('Success', res.data.message);
          setBookmarkLoad(true)
          // setisLoading(true)
          formData.append('user_id',props.user_id); 

          Axios
            .post(`${api_url.userDetails}`, formData)
            .then(res =>{
              console.log('after bookmark')
              console.log(res.data)
              setProfile([res.data.aboutuser]);
              // setIsLoading(false);
              setBookmarkLoad(false)
      
            })
        }
        if(res.data.error){
          Alert.alert('Success', res.data.error);
        }
    })
  }


  return (
    <SafeAreaView style={styles.container}> 
    {isLoading?<ActivityIndicator color="green" size="large" />:
      Profile.map((profile,i)=>   <ScrollView key={i}><View style={styles.userInfoSection} >
      
        <View style={{flexDirection: 'row', marginTop: 15}}>
          <Avatar.Image 
            source={{
              uri: profile.profilepic,
            }}
            size={80}
          />
          <View style={{marginLeft: 20}}>
            <Title style={[styles.title, {
              marginTop:1,
              marginBottom: 5,
            }]}>{profile.firstname} {profile.lastname}</Title>
            <Caption style={styles.caption}>{profile.jobtitle}</Caption>
            <Caption style={styles.caption1}>{profile.companyname}</Caption>
          </View>
        </View>
        <View style={styles.userInfoSection}>
      <View style={styles.row}>
        <Icon name="map-marker-radius" color="#000" size={20}/>
          <Text style={{color:"#000", marginLeft: 20}}>{profile.billing_address_1}, {profile.billing_address_2}, {profile.billing_city}, {profile.billing_postcode}</Text>
      </View>
      {profile.phone?
      <View style={styles.row}>
        <Icon name="phone" color="#000" size={20}/>
        <Text style={{color:"#000", marginLeft: 20}}>{profile.phone?profile.phone:''}</Text>
      </View>
      :<Text></Text>}
      <View style={styles.row}>
        <Icon name="email" color="#000" size={20}/>
        <Text style={{color:"#000", marginLeft: 20}}>{profile.email}</Text>
      </View>
     
    </View>
    <View>
    {/* <Text style={{color:"#05CB9A", marginLeft: 20 , fontSize:18, fontWeight:'500', paddingBottom:5,}}>Profile</Text> */}
    </View>
          <View style={styles.row}> 
          <HTML
                tagsStyles= {{p: { lineHeight: 22,marginBottom:10} } }
                html={"<p>"+profile.description +"</p>" }
                imagesMaxWidth={Dimensions.get('window').width} /> 
          </View>

          <View style={{
            display:"flex",
            flexDirection:"row",
            padding:15,
            marginLeft:40
          }}>
          <TouchableOpacity style={{
            width:100,
            marginRight:40
          }} onPress={()=> bookmark(profile)}> 
              <View>
                 
                  {bookmarkLoad?<ActivityIndicator size="small" color="green" />:
                    <IonIcon name={profile.user_bookmark_status?'bookmark':'bookmark-outline'} size={40} color="#1E1727" />}
                 
              </View> 
            </TouchableOpacity>
            
            <TouchableOpacity style={{  
            }} onPress={()=> navigation.navigate('meetinglist',{screen:'Request', id:profile.id, name:`${profile.firstname} ${profile.lastname}`})}
            
            >
             <IonIcon name="people-outline" size={40} color="#1E1727" />
             {/* <Icon name="meeting-room" size={30} color="#4F8EF7" /> */}
             
                 
                {/* <Image
                      source={require('../assets/icons/interview.png')}
                      resizeMode="cover"
                      style={styles.iconWidth}
                    /> */}
                </TouchableOpacity>
                </View>

      </View>
      </ScrollView>
      )}
      

      {/* <View style={styles.infoBoxWrapper}>
          <View style={[styles.infoBox, {
            borderRightColor: '#dddddd',
            borderRightWidth: 1
          }]}>
            <Title>₹140.50</Title>
            <Caption>Wallet</Caption>
          </View>
          <View style={styles.infoBox}>
            <Title>12</Title>
            <Caption>Orders</Caption>
          </View>
      </View> */}

      
    
    
    
    </SafeAreaView>
    
  );
};

// export default ProfileCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  userInfoSection: {
   // paddingTop:10,
    paddingVertical:10,
    paddingHorizontal: 20,
   
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  caption: {
    fontSize: 14,
    lineHeight: 14,
    fontWeight: '500',
  },
  caption1: {
    fontSize: 15,
    lineHeight: 18,
    fontWeight: '600',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  infoBoxWrapper: {
    borderBottomColor: '#dddddd',
    borderBottomWidth: 1,
    borderTopColor: '#dddddd',
    borderTopWidth: 1,
    flexDirection: 'row',
    height: 100,
  },
  infoBox: {
    width: '50%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuWrapper: {
    marginTop: 10,
  },
  menuItem: {
    flexDirection: 'row',
    paddingVertical: 15,
    paddingHorizontal: 30,
  },
  menuItemText: {
    color: '#000',
    marginLeft: 20,
    fontWeight: '600',
    fontSize: 16,
    lineHeight: 26,
  },
});


const mapStateToProps = state =>{
  return (
    {
      login:state.login
    }
  )
}


export default connect(mapStateToProps)(UserDetailsCard)