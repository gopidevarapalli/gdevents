import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { useNavigation, useTheme } from "@react-navigation/native";
import { Button } from "react-native-paper";
import IonIcon from "react-native-vector-icons/Ionicons";

const SponsorCard = (props) => {
  const theme = useTheme();

  const navigation = useNavigation();

  // console.log(props)
  // const [Sponsors, setSpeakers] = useState(props.SponsorsData);

  const [SponsorsDta, setSponsors] = useState(props.sponsorsData);

  // useEffect(()=>{
  //   console.log('sponsors called');
  //   console.log(SponsorsDta)
  //     // console.log(Sponsors)
  // },[])

  // const bookmark = (sponsor)=>{
  //   const formData = new FormData();
  //   formData.append('cookie',store.getState().login.cookie);
  //   formData.append('bookmarktype','products');
  //   formData.append('status',sponsor.bookmarkstatus?0:1);
  //   formData.append('title',sponsor.company);
  //   formData.append('id',sponsor.id);
  //   console.log(sponsor)
  //   Axios.post(`https://ind-backend-events-website.pantheonsite.io/api/user/add_bookmarks`, formData)
  //   .then(res=>{
  //     // console.log(res.data);
  //       if(res.data.status === "ok"){
  //         Alert.alert('Success', res.data.message);
  //           Axios
  //           .post(`https://ind-backend-events-website.pantheonsite.io/api/user/get_sponsors`, formData)
  //           .then(res =>{
  //               setSponsors(res.data.products);
  //           });
  //       }
  //       if(res.data.error){
  //         Alert.alert('Success', res.data.error);
  //       }
  //   })

  // }

  useEffect(() => {
    console.log(props.sponsorsData);
  }, []);

  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle={theme.dark ? "light-content" : "dark-content"} />
      <View style={styles.cardsWrapper}>
        <Text style={styles.stitle}>Platinum Sponsors :</Text>
        {/* {SponsorsDta.map((sponsor,i) => <View style={styles.scard} key={i}>   */}
        <View style={styles.scard}>
          {SponsorsDta.Platinum ? (
            SponsorsDta.Platinum.map((platinum, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: platinum.id })
                }
                style={styles.scardinfo}
                key={i}
              >
                <Image
                  source={{ uri: platinum.SponsorLogo }}
                  resizeMode="contain"
                  style={styles.attendeeSize}
                />
                {/* <Text style={styles.cardTitle}>{platinum.sponsorname}</Text> */}
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>
      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Gold Sponsors : </Text>
        </View>

        {/* {SponsorsDta.map((sponsor,i) => <View style={styles.scard} key={i}>   */}
        <View style={styles.scard}>
          {SponsorsDta.Gold ? (
            SponsorsDta.Gold.map((gold, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: gold.id })
                }
                style={styles.scardinfo}
                key={i}
              >
                <Image
                  source={{ uri: gold.SponsorLogo }}
                  resizeMode="contain"
                  style={styles.attendeeSize}
                />
                {/* <Text style={styles.cardTitle}>{gold.sponsorname}</Text> */}
                {/* </View>  
      )} */}
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>
      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Silver Sponsors : </Text>
        </View>

        {/* {SponsorsDta.map((sponsor,i) => <View style={styles.scard} key={i}>   */}
        <View style={styles.scard}>
          {SponsorsDta.Silver ? (
            SponsorsDta.Silver.map((silver, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: silver.id })
                }
                style={styles.scardinfo}
                key={i}
              >
                <Image
                  source={{ uri: silver.SponsorLogo }}
                  resizeMode="contain"
                  style={styles.attendeeSize}
                />
                {/* <Text style={styles.cardTitle}>{silver.sponsorname}</Text> */}
                {/* </View>  
      )} */}
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>
      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Bronze Sponsors : </Text>
        </View>

        <View style={styles.scard}>
          {SponsorsDta.Bronze ? (
            SponsorsDta.Bronze.map((bronze, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: bronze.id })
                }
                style={styles.scardinfo}
                key={i}
              >
                <Image
                  source={{ uri: bronze.SponsorLogo }}
                  resizeMode="contain"
                  style={styles.attendeeSize}
                />
                {/* <Text style={styles.cardTitle}>{bronze.sponsorname}</Text> */}
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
          {/* </View> 
    )} */}
        </View>
      </View>
    </ScrollView>
  );
};

export default SponsorCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  stitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#05CB9A",
    alignSelf: "center",
    padding: 5,
    lineHeight: 25,
  },
  scardinfo: {
    height: 100,
    width: "50%",
    backgroundColor: "#fff",
  },
  scard: {
    flex: 1,
    //width:"98%",
    marginTop: 20,
    flexDirection: "row",
    flexWrap: "wrap",
  },
  attendeeBtn1: {},
  cardsWrapper: {
    marginTop: 20,
    width: "98%",
    alignSelf: "center",
  },
  card1: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    height: 200,
    width: "100%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
  },
  cardTitle: {
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
    marginTop: 10,
  },

  attendeeSize: {
    width: 200,
    height: 45,
    maxWidth:"100%"
    // marginRight:15,
    // flex:1,
  },
});
