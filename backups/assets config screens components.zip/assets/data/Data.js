export const dummyData =
        [{
                title: 'THE DIGITAL ACCOUNTANCY FORUM AND AWARDS – A VIRTUAL EXPERIENCE', url: 'https://globaldata.web.app/assets/img/hero-slider/mobile/slider-3.jpg',
                description: "17 JUL 2020 - 30 DEC 2020" ,
                id: 1

        },
        {
                title: 'THE DIGITAL ACCOUNTANCY FORUM AND AWARDS – A VIRTUAL EXPERIENCE', url: 'https://globaldata.web.app/assets/img/hero-slider/mobile/slider-3.jpg',
                description: "17 JUL 2020 - 30 DEC 2020" ,
                id: 1

        },
   ]