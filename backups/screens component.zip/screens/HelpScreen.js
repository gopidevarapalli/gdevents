import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  useWindowDimensions,
  ScrollView,
} from "react-native";
import { WebView } from "react-native-webview";

export default function HelpScreen() {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={{ flex: 1, height: 400 }}>
          <Text style={{ fontSize: 20 }}>Introduction</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6184955925001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Speakers, Companies and Products</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6185283988001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>My Relationships</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6185288227001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>My Meetings</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6185288577001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Exhibitors and Sponsors</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6185293964001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Attendees</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6185309633001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Agenda</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6186178646001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Leaderboard</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6186179787001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>Messages</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6186228636001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>

        <View style={{ marginTop: 20 }}></View>

        <View style={{ flex: 1, height: 400, marginTop: -170 }}>
          <Text style={{ fontSize: 20 }}>3D Virtual Walk Through</Text>
          <WebView
            source={{
              html:
                '<iframe width="100%" height=500 src="https://players.brightcove.net/49921910001/BylJ9vjKeb_default/index.html?videoId=6206287949001" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>',
            }}
            style={{ marginTop: 20 }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    //alignItems: 'center',
    //justifyContent: 'center',
    padding: 16,
  },
});
