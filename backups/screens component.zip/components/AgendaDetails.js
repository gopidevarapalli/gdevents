import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Alert,
  AsyncStorage,
} from "react-native";
import HTML from "react-native-render-html";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import { useNavigation, useTheme } from "@react-navigation/native";
import Axios from "axios";
import store from "../redux/store";

import { Button } from "react-native-paper";
import moment from "moment";
import CountDown from "react-native-countdown-component";
import * as AddCalendarEvent from "react-native-add-calendar-event";
import api_url from "../Config/Config";
import { connect } from "react-redux";

const AgendaDetails = (props) => {
  const theme = useTheme();

  const navigation = useNavigation();

  // console.log(props)
  const [agendaData, setagendaData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const [todayDate, setTodayDate] = useState(new Date());

  const [speaker, setSpeaker] = useState([]);

  useEffect(() => {
    // alert(props.route.params.id);
    // alert(props.event.common.event.event_id_single)

    let formData = new FormData();
    // formData.append('cookie', props.login.cookie);
    formData.append("agend_id", props.route.params.id);
    // formData.append('event_id',props.event.common.event.event_id_single);

    formData.append(
      "cookie",
      `yoganath1265|1607497047|fDCk2aTwkeoI8L203M3OthVonmFefQPeGSRpsOS8GQr|1a0d8bf324ba1de0db949060813b612c12f7f68777289d40ccbf5760ef896d22`
    );
    formData.append("event_id", props.event.common.event.event_id_single);

    // Axios.post(`https://ind-ew-events-website.pantheonsite.io/api/user/get_agenda_v1`, formData)
    // alert(event_id)

    // console.log(store.getState().login.common.user.id)

    // Axios.post(`${api_url.agendaDetails}`,formData)
    Axios.post(
      "https://ind-ew-events-website.pantheonsite.io/api/user/agenda_details",
      formData
    ).then((res) => {
      // console.log('55')
      // console.log(res.data);

      if (res.data.agenda == null) {
        setagendaData([]);
        setSpeaker([]);
        setIsLoading(false);
      } else {
        setagendaData(res.data.agenda.length ? res.data.agenda[0] : []);
        setSpeaker(
          res.data.agenda.length
            ? res.data.agenda[0].speakerlist.filter(
                (item) => item.speakerId == props.login.common.user.id
              )
            : []
        );
        setIsLoading(false);
      }
      // console.log(res.data.agenda[0].speakerlist)
      // console.log(res.data.agenda[0].speakerlist.filter(item=>item.speakerId == 120))
      // if(res.data.agenda[0].speakerlist.indexOf(store.getState().login.common.user.id) > -1){
      //   setSpeaker([
      //     {
      //       user_id:store.getState().login.common.user.id
      //     }
      //   ])
      // }
      //  console.log(res.data.agenda[0].speakerlist.indexOf(store.getState().login.common.user.id))

      // console.log(res.data.agenda[0].speakerlist)

      // setIsLoading(false);
      // console.log('agenda details')
    });
  }, [props.route.params.id]);

  const getTiming = (agendaTime) => {
    var otherDate = moment(agendaTime).format("DD-MM-YYYY HH:mm:ss");
    var today = new Date();
    var ms = moment(otherDate, "DD/MM/YYYY HH:mm:ss").diff(
      moment(today, "DD/MM/YYYY HH:mm:ss")
    );
    var d = moment.duration(ms);
    var s = Math.floor(d.asHours()) + moment.utc(ms).format(":mm:ss");

    // alert(ms);
    return ms / 1000;
  };

  const utcDateToString = (momentInUTC) => {
    let s = moment
      .utc(momentInUTC)
      .add(-5.49, "hours")
      .format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
    return s;
  };

  const addCalender = (title, startDate, endDate) => {
    startDate = utcDateToString(startDate);
    endDate = utcDateToString(endDate);
    const eventConfig = {
      title: title,
      startDate: startDate,
      endDate: endDate,
    };
    AddCalendarEvent.presentEventCreatingDialog(eventConfig).then((res) => {
      Alert.alert("Success", res.action);
      console.log("add to calender");
      console.log(res);
    });
  };

  // .then((eventInfo: { calendarItemIdentifier: string, eventIdentifier: string }) => {
  //   // handle success - receives an object with `calendarItemIdentifier` and `eventIdentifier` keys, both of type string.
  //   // These are two different identifiers on iOS.
  //   // On Android, where they are both equal and represent the event id, also strings.
  //   // when { action: 'CANCELED' } is returned, the dialog was dismissed
  //   console.warn(JSON.stringify(eventInfo));
  // })
  // .catch((error: string) => {
  //   // handle error such as when user rejected permissions
  //   console.warn(error);
  // });

  return isLoading ? (
    <ActivityIndicator color="green" size="large" />
  ) : (
    <View style={styles.container}>
      <ScrollView>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <TouchableOpacity>
            {/* <View style={{borderRadius:5, height:30, width:30, backgroundColor:"#ddd", borderRadius:30, marginLeft:"78%" }}>
     <Text style={{color:"#000", textAlign:"center", marginTop:3}}>Remove from my Favorites</Text> 
     <MaterialIcons style={{marginLeft:5, marginTop:4}} name ="favorite" size={20} color="#000" />
 </View> */}
          </TouchableOpacity>
        </View>
        <View style={{ marginTop: 20 }}></View>

        <TouchableOpacity style={styles.card}>
          <View style={styles.cardInfo}>
            <View style={styles.agendaCardDetails}>
              <Text
                style={{ textAlign: "center", color: "white", fontSize: 10 }}
              >
                {agendaData.session_start_time} - {agendaData.session_end_time}
              </Text>
            </View>

            <Text style={styles.cardDetails}>{agendaData.agend_title}</Text>
            <View style={{ flexDirection: "row" }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "#1E1727",
                  marginLeft: 4,
                  marginRight: 4,
                  paddingTop: 4,
                  paddingLeft: 5,
                  paddingRight: 5,
                  paddingBottom: 4,
                  marginTop: 8,
                  borderRadius: 5,
                }}
              >
                <Text
                  style={{ fontSize: 10, color: "white" }}
                  onPress={() =>
                    addCalender(
                      agendaData.agend_title,
                      agendaData.twf_session_start_time,
                      agendaData.twf_session_end_time
                    )
                  }
                >
                  Add to Calender
                </Text>
              </TouchableOpacity>
              {/* <TouchableOpacity
                              style={{backgroundColor:'#1E1727', color:'white', paddingTop: 4, paddingLeft:5,paddingRight:5, paddingBottom:4, marginTop:8,borderRadius:5 }}
                              
                                >
                            <Text style={{fontSize:10,color:'white'}}>Add to my Schedule</Text>
                          </TouchableOpacity> */}
            </View>
          </View>
        </TouchableOpacity>

        <View>
          {/* <CountDown
                                    until={ (  Math.abs(Math.abs(moment(todayDate).format("DD") - moment(agendaData.twf_session_start_time).format("DD")) ) *24*60*60 )  + (Math.abs(moment(todayDate).format('HH') - moment(agendaData.twf_session_start_time).format("HH"))*60*60 ) +     (Math.abs(moment(todayDate).format("MM") - moment(agendaData.twf_session_start_time).format("MM")  ) *60 )             }
                                    onFinish={() => alert('Meeting Started')}
                                    onPress={() => alert('hello')}
                                    size={15}
                                  /> */}
          <Button
            style={{ margin: 8 }}
            color="#C21383"
            disabled={
              moment(todayDate).format("DD-MM-YYYY") ==
                moment(agendaData.twf_session_start_time).format(
                  "DD-MM-YYYY"
                ) &&
              moment(todayDate).format("HH:mm") >=
                moment(agendaData.twf_session_start_time).format("HH:mm")
                ? false
                : true
            }
            contentStyle={{ height: 34 }}
            labelStyle={{ color: "white", fontSize: 12 }}
            mode="contained"
            onPress={() => {
              if (props.route.params.provider == "Vonage") {
                navigation.navigate("sessionscreen", {
                  token: agendaData.token,
                  type: "agenda",
                  speaker: speaker,
                });
              } else {
                Alert.alert(
                  "Warning!",
                  "Sorry This meeting can only open in web"
                );
              }
            }}
          >
            Join
          </Button>

          {moment(todayDate).format("DD-MM-YYYY") >
          moment(agendaData.twf_session_start_time).format("DD-MM-YYYY") ? (
            <Text></Text>
          ) : moment(todayDate).format("DD-MM-YYYY") ==
              moment(agendaData.twf_session_start_time).format("DD-MM-YYYY") &&
            moment(todayDate).format("HH:mm") >=
              moment(agendaData.twf_session_start_time).format("HH:mm") ? (
            <View>
              <Text>Meeting Started</Text>

              <Text>Meeting End In:</Text>
              <CountDown
                until={getTiming(agendaData.twf_session_end_time)}
                // onFinish={() => alert("Meeting Ended")}
                size={15}
              />
            </View>
          ) : moment(todayDate).format("DD-MM-YYYY HH:mm:ss") <
            moment(agendaData.twf_session_start_time).format(
              "DD-MM-YYYY HH:mm:ss"
            ) ? (
            <View>
              <Text>Meeting Starts In:</Text>
              <CountDown
                until={getTiming(agendaData.twf_session_start_time)}
                onFinish={() => alert("Meeting Started")}
                size={15}
              />
            </View>
          ) : (
            <Text></Text>
          )}
        </View>

        <View style={{ marginTop: 20 }}>
          <HTML
            tagsStyles={{ p: { lineHeight: 22, padding: 0, marginBottom: 10 } }}
            html={"<p>" + agendaData.agend_content + "</p>"}
            imagesMaxWidth={Dimensions.get("window").width}
          />
        </View>

        <View>
          <Text style={{ fontWeight: "600" }}>Speakers</Text>
          {agendaData.speakerlist == undefined ? (
            <View></View>
          ) : (
            agendaData.speakerlist.map((speaker, i) => {
              //console.log(speaker)
              return (
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate("userDetails", {
                      user_id: speaker.speakerId,
                    })
                  }
                  key={i}
                >
                  <View style={styles.card1}>
                    <View style={styles.cardImgWrapper1}>
                      <View style={styles.cardImg1}>
                        <Image
                          source={{ uri: speaker.profilepic }}
                          resizeMode="cover"
                          style={styles.iconWidth}
                        />
                      </View>
                    </View>
                    <View style={styles.cardInfo}>
                      <Text style={styles.cardTitle}>
                        {speaker.fname} {speaker.lname}
                      </Text>
                      <Text style={styles.cardDesg}>{speaker.jobtitle}</Text>
                      {/* <Text numberOfLines={2} style={styles.cardDetails}>
             {speaker.profileurl}
            </Text> */}
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })
          )}
        </View>

        {agendaData.webinar_embedded_code == "" ? (
          <Text></Text>
        ) : (
          <View style={{ marginTop: 20 }}>
            <Text style={{ fontWeight: "bold" }}>Recorded Video</Text>
            <HTML
              tagsStyles={{
                p: { lineHeight: 22, padding: 0, marginBottom: 10 },
              }}
              html={agendaData.webinar_embedded_code}
              imagesMaxWidth={Dimensions.get("window").width}
            />
          </View>
        )}
        <View>
          <Text>Sponsors</Text>
          {agendaData ? (
            agendaData.sponsorlist ? (
              agendaData.sponsorlist.map((speaker, i) => {
                console.log(speaker.SponsorLogo);
                return (
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate("SponsorDetail", {
                        id: speaker.sponsorId,
                      })
                    }
                    key={i}
                  >
                    <View style={styles.card}>
                      <View style={styles.cardImgWrapper1}>
                        <Image
                          source={{ uri: speaker.SponsorLogo }}
                          resizeMode="cover"
                          style={styles.iconWidthSponsor}
                        />
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })
            ) : (
              <View></View>
            )
          ) : (
            <View></View>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    height: "auto",
    width: "98%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
    flexDirection: "row",
    shadowColor: "#999",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
    elevation: 5,
    borderWidth: 0.2,
    borderRadius: 8,
  },
  card1: {
    height: 140,
    width: "98%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
    flexDirection: "row",
    shadowColor: "#999",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
    elevation: 5,
    borderWidth: 0.2,
    borderRadius: 8,
  },
  iconWidth: {
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 14,
    width: 55,
    height: 55,
    marginLeft: 10,
    borderRadius: 30,
  },
  iconWidthSponsor: {
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 14,
    width: 170,
    height: 185,
    // marginLeft:10,
  },
  cardImg: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    flexDirection: "column",

    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
    borderLeftWidth: 0,
  },
  cardImgWrapper1: {
    height: 210,
    width: "100%",
    flex: 1,
    borderRightWidth: 0,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
  },
  cardImg1: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderLeftWidth: 0,
  },
  cardText: {
    borderRadius: 8,
  },
  cardInfo: {
    flex: 3,
    padding: 10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    lineHeight: 24,
  },
  cardDesg: {
    fontSize: 14,
    fontWeight: "600",
    color: "#444",
    lineHeight: 20,
  },
  iconWidth: {
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 14,
    width: 55,
    height: 55,
    marginLeft: 10,
    borderRadius: 30,
  },
  cardImg: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    flexDirection: "column",

    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
    borderLeftWidth: 0,
  },
  cardImg1: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderLeftWidth: 0,
  },
  container: {
    flex: 1,
    padding: 16,
  },
  cardBody: {
    backgroundColor: "#fff",
    padding: 16,
    flexDirection: "row",
    borderRadius: 15,
    borderColor: "#fff",
    borderWidth: 1,
  },
  cardDetails: {
    // paddingHorizontal: 20
  },
  headDetails: {
    flexDirection: "row",
  },
  textBody: {
    fontWeight: "bold",
    // flexDirection:"row"
  },
  designation: {
    fontSize: 12,
  },
  company: {
    fontSize: 11,
    fontWeight: "bold",
  },
  optionss: {
    //backgroundColor: '#fff',
    //marginTop:15,
    paddingTop: 10,
    height: 35,
    borderColor: "#f2f2f2",
    flexDirection: "row",
    justifyContent: "space-around",
  },
  agendaCardDetails: {
    backgroundColor: "#1E1727",
    width: 80,
    color: "white",
    textAlign: "center",
    padding: 2,
    marginBottom: 5,
    borderRadius: 5,
    marginTop: 2,
  },
});

const mapStateToProps = (state) => {
  return { login: state.login, event: state.Event };
};

// export default AgendaDetails;

export default connect(mapStateToProps)(AgendaDetails);
