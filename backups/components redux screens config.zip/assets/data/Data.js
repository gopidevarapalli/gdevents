import React from 'react';
import Axios from "axios"
import { connect } from "react-redux"

export const dummyData =
        [{
                title: 'THE DIGITAL ACCOUNTANCY FORUM AND AWARDS – A VIRTUAL EXPERIENCE', url: 'https://globaldata.web.app/assets/img/hero-slider/mobile/slider-3.jpg',
                description: "17 JUL 2020-19 AUG 2020" ,
                id: 1

        },
        {
                title: 'THE DIGITAL ACCOUNTANCY FORUM AND AWARDS – A VIRTUAL EXPERIENCE', url: 'https://globaldata.web.app/assets/img/hero-slider/mobile/slider-3.jpg',
                description: "17 JUL 2020-19 AUG 2020" ,
                id: 1

        },
   ]
   
const Data = () =>{
         
        useEffect(()=>{

        }, [props.login.cookie])
 


}

   const mapStateToProps = state =>{
           return ({
                   event: state.Event,
                   login: state.login
           })
   }

   export default connect(mapStateToProps)(Data);

   