export default Notifications = [
    {
        id: 1,
        title: 'Dolle Liked your post',
        details: '2 weeks ago'
    },
    {
        id: 2,
        title: 'Steve,liked your comment on your post',
        details: '2 weeks ago.'
    },
    {
        id: 3,
        title: 'Dolle Liked your post',
        details: '2 weeks ago.'
    },
    {
        id: 4,
        title: 'Steve Liked your post',
        details: '2 weeks ago.'
    },
    {
        id: 5,
        title: 'Steve Liked your post',
        details: '2 weeks ago.'
    }
   
];