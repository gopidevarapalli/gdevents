import Axios from "axios";
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Button,
  StyleSheet,
  ActivityIndicator,
  AsyncStorage,
} from "react-native";
import { connect } from "react-redux";

import Agenda from "../components/Agenda";
import api_url from "../Config/Config";
import store from "../redux/store";

const data = require("../assets/data.json");

const AgendaScreen = (props) => {
  state = {
    AgendaData: data.Agenda,
  };
  const [agenda, setAgenda] = useState();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // AsyncStorage.getItem('event_id')
    // .then((event_id)=>{
    // alert(event_id)
    const formData = new FormData();
    // formData.append('cookie', store.getState().login.cookie);
    // formData.append('event_id', props.event.common.event.event_id_single)
    formData.append(
      "cookie",
      `SHEA|1608731700|uK0gR5MZnkoejUhUSzm4qpxfdWfDippRZGHRuU2eqvv|9b74b844f7c3081219c8602c1deba917a3a7855d2c52d441eff0fe3156a0cb4a`
    );
    formData.append("event_id", props.event.common.event.event_id_single);
    Axios.post(
      `https://ind-ew-events-website.pantheonsite.io/api/user/get_agenda_v1`,
      formData
    ).then((res) => {
      setAgenda(res.data.agenda);
      setIsLoading(false);
    });
    // })
  }, [props.login.cookie]);

  const [AgendaData, setAgendaData] = useState(data.Agenda);
  return isLoading ? (
    <ActivityIndicator size="large" color="green" />
  ) : (
    <Agenda AgendaData={agenda} />
  );
};

const mapStateToProps = (state) => {
  return {
    login: state.login,
    event: state.Event,
  };
};

export default connect(mapStateToProps)(AgendaScreen);
