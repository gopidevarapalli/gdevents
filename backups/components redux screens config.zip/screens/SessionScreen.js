import React, { useEffect, useState, Component } from "react";
import {
  View,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  StyleSheet,
  Alert,
  Text,
  AsyncStorage,
} from "react-native";
// import {
//   OTSession,
//   OTPublisher,
//   OTSubscriber,
//   OTSubscriberView,
// } from "opentok-react-native";

import {
  TouchableOpacity,
  TouchableHighlight,
} from "react-native-gesture-handler";
// import Orientation from 'react-native-orientation';
// import Subscriber from './Subscriber';
// import Publisher from './Publisher';
import Axios from "axios";
import { connect } from "react-redux";

import FontAwesome from "react-native-vector-icons/FontAwesome";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Ionicons from "react-native-vector-icons/Ionicons";

import Feather from "react-native-vector-icons/Feather";
// import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { Button } from "react-native-share";
import api_url from "../Config/Config";
// import Orientation from "react-native-orientation";

let deviceHeight = Dimensions.get("window").height;
let deviceWidth = Dimensions.get("window").width;
let landscapeHeight = 350;

let streamIdList = [];

class SessionScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      orientation: "potrait",
      navigation: props.navigation,
      apiKey: "",
      sessionId: "",
      token: "",
      isLoading: true,
      streamProperties: {},

      publishAudio: true,
      publishVideo: true,
      cameraPosition: "front",
      bigScreenUser: "",
      subscribeSelf: false,
      nosubscriber: false,
    };

    this.getToken();

    this.subscriberProperties = {
      subscribeToAudio: true,
      subscribeToVideo: true,
    };

    this.sessionEventHandlers = {
      streamCreated: (event) => {
        const streamProperties = {
          ...this.state.streamProperties,
          [event.streamId]: {
            subscribeToAudio: true,
            subscribeToVideo: true,
            style: {
              width: 100,
              height: 100,
              flex: 1,
              flexDirection: "row",
            },
          },
        };
        this.setState({ streamProperties });
      },
    };

    this.subscriberEventHandlers = {
      error: (error) => {
        console.log(`There was an error with the subscriber: ${error}`);
      },
    };
  }

  componentWillMount() {
    // const initial = Orientation.getInitialOrientation();
    // alert(initial)
    // if (initial === "PORTRAIT") {
      // do something
    // } else {
      // do something else
    // }
  }

  getToken() {
    // console.log(1111111111111111111111111111111111111111)
    // console.log(this.props.login.common.user.displayname)
    // alert(this.props.route.params.token)

    // alert(this.props.route.params.speaker.length)
    let formData = new FormData();
    formData.append("cookie", this.props.login.cookie);
    formData.append("token", this.props.route.params.token);
    if (this.props.route.params.type === "agenda") {
      formData.append(
        "event_id",
        this.props.event.common.event.event_id_single
      );
      Axios.post(`${api_url.JoinAgenda}`, formData).then((res) => {
        console.log("=================================");
        console.log(res.data);
        console.log("=================================");
        if (res.data.error) {
          Alert.alert("Warning!", res.data.error, [
            { text: "OK", onPress: () => this.props.navigation.goBack() },
          ]);
        }
        if (res.data.provider && res.data.provider == "dailyco") {
          Alert.alert(
            "Warning!",
            "This meeting can only support in website only.",
            [{ text: "OK", onPress: () => this.props.navigation.goBack() }]
          );
        }
        this.setState({
          token: res.data.data.token,
          sessionId: res.data.data.session,
          apiKey: res.data.data.apiKey,
          isLoading: false,
        });
      });
    } else {
      AsyncStorage.getItem("event_id").then((event_id) => {
        formData.append("event_id", event_id);
        Axios.post(`${api_url.launchMeeting}`, formData).then((res) => {
          // console.log(res.data);
          if (res.data.error) {
            Alert.alert("Warning!", res.data.error, [
              { text: "OK", onPress: () => this.props.navigation.goBack() },
            ]);
          }
          this.setState({
            token: res.data.data.token,
            sessionId: res.data.data.session,
            apiKey: res.data.data.apiKey,
            isLoading: false,
          });
        });
      });
    }
  }

  EndMeeting() {
    alert("Session Closed");
    this.props.navigation.goBack();
  }

  publisherEventHandlers = {
    streamCreated: (event) => {
      console.log("Publisher stream created!", event);
    },
    streamDestroyed: (event) => {
      console.log("Publisher stream destroyed!", event);
    },
  };
  setAudioToggle() {
    this.setState({
      publishAudio: !this.state.publishAudio,
    });
  }
  setVideoToggle() {
    this.setState({
      publishVideo: !this.state.publishVideo,
    });
  }
  setCameraPosition() {
    this.setState({
      cameraPosition: this.state.cameraPosition === "front" ? "back" : "front",
    });
  }

  // subscriber stream manage
  handleStreamPress(streamId) {
    // console.log(streamId);
    // this.setState({bigScreenUser:<OTSubscriberView streamId={streamId} style={styles.big} />})

    this.setState({ bigScreenUser: streamId });

    // alert(streamId);
  }

  // Render prop function

  

  componentWillUnmount() {
    // Orientation.unlockAllOrientations();
  }

  componentDidMount() {
    if (
      this.state.bigScreenUser == "" &&
      this.props.route.params.speaker.length == 0
    ) {
      // if(streamIdList.length){
      this.setState(
        {
          bigScreenUser:
            streamIdList[0] && streamIdList[0] != "" ? streamIdList[0] : "",
        },
        () => {
          console.log("on mount");
          console.log(this.state.bigScreenUser);
        }
      );
      // }
    }

    if (!streamIdList.length) {
      this.setState({
        nosubscriber: true,
      });
    }

    Dimensions.addEventListener("change", ({ window: { height, width } }) => {
      // console.log('Dimensions add event listener')

      if (width < height) {
        // console.log('potrait mode')
        this.setState({
          orientation: "potrait",
        });
      } else {
        // console.log('landscape mode')
        this.setState({
          orientation: "landscape",
        });
      }
    });
  }

  render() {
    return ( <View></View>
      )    
}

}
const styles = StyleSheet.create({
  big: {
    width: deviceWidth,
    height: deviceHeight,
  },
  landscapeStyle: {
    width: deviceHeight,
    height: deviceWidth,
  },
  small: {
    height: 130,
    width: 130,
  },
  smallPublisher: {
    height: 130,
    width: 130,
    zIndex: 99,
  },
});

const mapStateToProps = (state) => {
  return {
    login: state.login,
    event: state.Event,
  };
};

export default connect(mapStateToProps)(SessionScreen);
