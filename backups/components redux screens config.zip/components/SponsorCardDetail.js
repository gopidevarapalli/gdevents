import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from "react-native";

import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import EvilIcons from "react-native-vector-icons/EvilIcons";
import AntDesign from "react-native-vector-icons/AntDesign";

import { useTheme } from "@react-navigation/native";
import { Button } from "react-native-paper";
import IonIcon from "react-native-vector-icons/Ionicons";
import { connect } from "react-redux";
import Axios from "axios";
import api_url from "../Config/Config";
import { SafeAreaView } from "react-native-safe-area-context";
const SponsorCardDetail = (props) => {
  const theme = useTheme();

  // console.log(props)
  const [sponsors, setsponsors] = useState([]);

  const [isLoading, setIsLoading] = useState(true);

  // if(isLoading){
  //   props.GetUserInfoAction(props.login.cookie, props.route.params.user_id);
  // }

  useEffect(() => {
    // alert(props.route.params.id)
    let formData = new FormData();
    formData.append("cookie", props.login.cookie);
    formData.append("sponsor_id", props.route.params.id);
    formData.append("event_id", props.event.common.event.event_id_single);

    Axios.post(`${api_url.sponsorDetail}`, formData).then((res) => {
      console.log(res.data);
      setsponsors(res.data.sponsors);
      setIsLoading(false);
    });
  }, [props.route.params.id]);

  return isLoading ? (
    <ActivityIndicator color="green" size="large" />
  ) : (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.container}>
          <Text
            style={{
              //marginLeft: 8,
              color: "black",
              fontSize: 20,
              marginTop: 2,
            }}
          >
            Sponsor Detail
          </Text>
          <View
            style={{
              borderBottomColor: "#20c997",
              borderBottomWidth: 2,
              marginTop: 10,
              width: 130,
            }}
          ></View>

          <View style={{ marginTop: 20 }}></View>

          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Text
              style={{
                color: "#20c997",
                fontSize: 20,
                marginTop: 2,
                // marginLeft: 10,
              }}
            >
              {sponsors.Sponsorname}
            </Text>

            <TouchableOpacity>
              <View
                style={{
                  borderRadius: 5,
                  height: 30,
                  width: 30,
                  backgroundColor: "#ddd",
                  borderRadius: 30,
                }}
              >
                {/* <Text style={{color:"#000", textAlign:"center", marginTop:3}}>Remove from my Favorites</Text> */}
                <MaterialIcons
                  style={{ marginLeft: 5, marginTop: 4 }}
                  name="favorite"
                  size={20}
                  color="#000"
                />
              </View>
            </TouchableOpacity>
          </View>

          <View style={{ marginTop: 20, marginLeft: 10 }}></View>
          <Text style={{ textAlign: "left", lineHeight: 17 }}>
            {sponsors.sponsorbio}
          </Text>

          <View style={{ marginTop: 20 }}></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderTopWidth: 1,
              borderLeftWidth: 1,
              borderRightWidth: 1,
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Sponsor Type
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.SponsorType}
              </Text>
            </View>
          </View>

          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              // width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Booth Name
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.booth_name}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              // width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Website
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.SponsorWebsite}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              // width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
              //height: 48,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Address
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.address1}, {sponsors.address2}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              // width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                City
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.City}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              // width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                State
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.State}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              //width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderLeftWidth: 1,
              borderRightWidth: 1,
              flexWrap: "wrap",
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Country
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.country}
              </Text>
            </View>
          </View>
          <View
            style={{
              borderBottomColor: "#bfbfbf",
              borderBottomWidth: 1,
              //width: "95%",
            }}
          ></View>

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              backgroundColor: "#f2f2f2",
              borderColor: "#ddd",
              borderBottomWidth: 1,
              borderLeftWidth: 1,
              borderRightWidth: 1,
              height: "auto",
              //height: 35,
            }}
          >
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginLeft: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                Zipcode
              </Text>
            </View>
            <View style={{ flex: 1, borderColor: "#ddd" }}>
              <Text
                style={{
                  color: "#000",
                  marginRight: 10,
                  marginTop: 5,
                  marginBottom: 5,
                }}
              >
                {sponsors.postzipcode}
              </Text>
            </View>
          </View>

          <View
            style={{
              marginTop: 10,
              flexDirection: "row",
              justifyContent: "center",
            }}
          >
            <TouchableOpacity>
              <MaterialCommunityIcons
                color="#20c997"
                name="facebook"
                size={22}
              />
            </TouchableOpacity>
            <TouchableOpacity style={{ marginLeft: 8 }}>
              <EvilIcons color="#20c997" name="sc-twitter" size={26} />
            </TouchableOpacity>
            <TouchableOpacity style={{ marginLeft: 8 }}>
              <AntDesign color="#20c997" name="linkedin-square" size={19} />
            </TouchableOpacity>
          </View>

          <View style={{ marginTop: 20 }}></View>

          {/* <View style={{alignItems:"center"}}><Text style={{fontSize:20}}>Delagates</Text></View>

            <View style={{marginTop:20}}></View>

            <View style={{alignItems:"center"}}><Text style={{fontSize:20}}>No users found</Text></View>

            <View style={{marginTop:20}}></View> */}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const mapStateToProps = (state) => {
  return {
    login: state.login,
    event: state.Event,
  };
};

export default connect(mapStateToProps)(SponsorCardDetail);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },

  cardsWrapper: {
    marginTop: 20,
    width: "90%",
    alignSelf: "center",
  },
  card: {
    height: 200,
    width: "98%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
    flexDirection: "row",
    shadowColor: "#999",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
    elevation: 5,
    borderWidth: 0.2,
    borderRadius: 8,
  },
  cardImgWrapper: {
    flex: 1,
    //padding:10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  iconWidth: {
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 14,
    width: 55,
    height: 55,
    marginLeft: 10,
    borderRadius: 30,
  },
  cardImg: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    flexDirection: "column",

    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
    borderLeftWidth: 0,
  },
  cardImgWrapper1: {
    flex: 1,
    borderRightWidth: 0,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
  },
  cardImg1: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderLeftWidth: 0,
  },
  cardText: {
    borderRadius: 8,
  },
  cardInfo: {
    flex: 3,
    padding: 10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    lineHeight: 24,
  },
  cardDetails: {
    fontSize: 13,
    // fontWeight:'600',
    color: "#444",
  },
  cardDesg: {
    fontSize: 14,
    fontWeight: "600",
    color: "#444",
    lineHeight: 20,
  },
  attendeeSize: {
    width: 20,
    height: 20,
    marginRight: 15,
  },
  attendeeIcon: {
    marginTop: 8,
    //  marginRight:35
  },
  speakerIcon: {
    marginTop: 10,
    alignSelf: "flex-end",
    paddingRight: 15,
  },
});
