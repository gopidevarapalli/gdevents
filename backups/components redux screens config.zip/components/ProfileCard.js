import React, { useEffect, useState } from "react";
import { View, SafeAreaView, StyleSheet } from "react-native";
import {
  Avatar,
  Title,
  Caption,
  Text,
  TouchableRipple,
} from "react-native-paper";

import Icon from "react-native-vector-icons/MaterialCommunityIcons";

import Share from "react-native-share";

import files from "../assets/filesBase64";

const ProfileCard = (props) => {
  const [Profile, setProfile] = useState([props.Profile]);

  useEffect(() => {
    // console.log(Profile)
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      {Profile.map((profile, i) => (
        <View style={styles.userInfoSection} key={i}>
          <View style={{ flexDirection: "row", marginTop: 15 }}>
            <Avatar.Image
              source={{
                uri: "https://events.globaldata.com/" + profile.avatar,
              }}
              size={80}
            />
            <View style={{ marginLeft: 20 }}>
              <Title
                style={[
                  styles.title,
                  {
                    marginTop: 1,
                    marginBottom: 5,
                  },
                ]}
              >
                {profile.displayname}
              </Title>
              <Caption style={styles.caption}>{profile.jobtitle}</Caption>
              <Caption style={styles.caption1}>{profile.company}</Caption>
            </View>
          </View>
          <View style={styles.userInfoSection}>
            <View style={styles.row}>
              <Icon name="map-marker-radius" color="#000" size={20} />
              <Text style={{ color: "#000", marginLeft: 20 }}>
                {profile.billing_address_1}, {profile.billing_address_2},{" "}
                {profile.billing_city}, {profile.billing_postcode}
              </Text>
            </View>
            <View style={styles.row}>
              <Icon name="phone" color="#000" size={20} />
              <Text style={{ color: "#000", marginLeft: 20 }}>
                {profile.billing_phone}
              </Text>
            </View>
            <View style={styles.row}>
              <Icon name="email" color="#000" size={20} />
              <Text style={{ color: "#000", marginLeft: 20 }}>
                {profile.billing_email}
              </Text>
            </View>
          </View>
          <View>
            {/* <Text style={{color:"#05CB9A", marginLeft: 20 , fontSize:18, fontWeight:'500', paddingBottom:5,}}>Profile</Text> */}
          </View>
          <View style={styles.row}>
            <Text style={{ color: "#000", marginLeft: 20, lineHeight: 21 }}>
              {profile.description}
            </Text>
          </View>
        </View>
      ))}

      {/* <View style={styles.infoBoxWrapper}>
          <View style={[styles.infoBox, {
            borderRightColor: '#dddddd',
            borderRightWidth: 1
          }]}>
            <Title>₹140.50</Title>
            <Caption>Wallet</Caption>
          </View>
          <View style={styles.infoBox}>
            <Title>12</Title>
            <Caption>Orders</Caption>
          </View>
      </View> */}
    </SafeAreaView>
  );
};

export default ProfileCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  userInfoSection: {
    // paddingTop:10,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  caption: {
    fontSize: 14,
    lineHeight: 14,
    fontWeight: "500",
  },
  caption1: {
    fontSize: 15,
    lineHeight: 18,
    fontWeight: "600",
  },
  row: {
    flexDirection: "row",
    marginBottom: 10,
  },
  infoBoxWrapper: {
    borderBottomColor: "#dddddd",
    borderBottomWidth: 1,
    borderTopColor: "#dddddd",
    borderTopWidth: 1,
    flexDirection: "row",
    height: 100,
  },
  infoBox: {
    width: "50%",
    alignItems: "center",
    justifyContent: "center",
  },
  menuWrapper: {
    marginTop: 10,
  },
  menuItem: {
    flexDirection: "row",
    paddingVertical: 15,
    paddingHorizontal: 30,
  },
  menuItemText: {
    color: "#000",
    marginLeft: 20,
    fontWeight: "600",
    fontSize: 16,
    lineHeight: 26,
  },
});
