import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  Linking,
} from "react-native";
import { useNavigation, useTheme } from "@react-navigation/native";
import { Button } from "react-native-paper";
import IonIcon from "react-native-vector-icons/Ionicons";

import Entypo from "react-native-vector-icons/Entypo";
import AntDesign from "react-native-vector-icons/AntDesign";

const SpeakersCard = (props) => {
  const theme = useTheme();
  const navigation = useNavigation();

   console.log("speakers card", props)
  const [speakers, setSpeakers] = useState(props.Speakers);

  useEffect(() => {
    // console.log(speakers)
  }, []);

  return speakers.length == 0 ? (
    <View style={{ flex: 1, textAlign: "center", textAlignVertical: "center" }}>
      <Text
        style={{ flex: 1, textAlign: "center", textAlignVertical: "center" }}
      >
        No Speakers available
      </Text>
    </View>
  ) : (
    <ScrollView style={styles.container}>
      <StatusBar barStyle={theme.dark ? "light-content" : "dark-content"} />
      <View style={styles.cardsWrapper}>
        {/* <Text style={styles.cardTitle}> Speakers</Text> */}
        {speakers.map((speaker, i) => (
          <TouchableOpacity
            onPress={() =>
              navigation.navigate("userDetails", { user_id: speaker.user_id })
            }
            key={i}
          >
            <View style={styles.card}>
              <View style={styles.cardImgWrapper1}>
                <View style={styles.cardImg1}>
                  <Image
                    source={{ uri: speaker.profile_pic }}
                    resizeMode="cover"
                    style={styles.iconWidth}
                  />
                </View>
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.cardTitle}>{speaker.speaker_name}</Text>
                <Text numberOfLines={2} style={styles.cardDesg}>
                  {speaker.job_title}
                </Text>
                <Text numberOfLines={2} style={styles.cardDetails}>
                  {speaker.session_title}
                </Text>
                <View style={{ flexDirection: "row" }}>
                  <TouchableOpacity
                    style={styles.attendeeBtn}
                    onPress={() =>
                      Linking.openURL(
                        speaker.fb_link.indexOf("http") < 0
                          ? "https://" + speaker.fb_link
                          : speaker.fb_link
                      )
                    }
                  >
                    <View
                      style={{
                        marginTop: 8,
                        padding: 2,
                        marginLeft: 5,
                      }}
                    >
                      <Entypo name="facebook" size={25} color="#3b5998" />
                      {/* <Image
              source={require('../assets/icons/facebook.png')}
              resizeMode="cover"
              style={styles.attendeeSize}
            /> */}
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.attendeeBtn}
                    onPress={() =>
                      Linking.openURL(
                        speaker.linkedin_link.indexOf("http") < 0
                          ? "https://" + speaker.linkedin_link
                          : speaker.linkedin_link
                      )
                    }
                  >
                    <View
                      style={{
                        marginTop: 8,
                        padding: 2,
                        marginLeft: 5,
                      }}
                    >
                      <AntDesign name="linkedin-square" size={25} />
                      {/* <Entypo name="linkedin" size={25} color="#00acee"   /> */}
                      {/* <Image
              source={require('../assets/icons/linkedin.png')}
              resizeMode="cover"
              style={styles.attendeeSize}
            /> */}
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.attendeeBtn}
                    onPress={() =>
                      Linking.openURL(
                        speaker.twitter_link.indexOf("http") < 0
                          ? "https://" + speaker.twitter_link
                          : speaker.twitter_link
                      )
                    }
                  >
                    <View
                      style={{
                        marginTop: 8,
                        padding: 2,
                        marginLeft: 5,
                      }}
                    >
                      <Entypo name="twitter" size={25} color="#00acee" />
                      {/* <Image
              source={require('../assets/icons/twi.png')}
              resizeMode="cover"
              style={styles.attendeeSize}
              
            /> */}
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.cardImgWrapper}>
                <View style={styles.cardImg}>
                  <TouchableOpacity style={styles.attendeeBtn}>
                    <TouchableOpacity
                      style={styles.speakerIcon}
                      onPress={() =>
                        navigation.navigate("meetinglist", {
                          screen: "Request",
                          id: speaker.user_id,
                          name: speaker.speaker_name,
                        })
                      }
                    >
                      <IonIcon
                        name="people-outline"
                        size={28}
                        color="#1E1727"
                      />
                      {/* <IonIcon name="ios-arrow-forward" size={25} color="#1E1727" /> */}
                    </TouchableOpacity>
                    {/* <TouchableOpacity style={styles.speakerIcon}  onPress={()=> navigation.navigate('messagelist',{screen:'New Message', params:{id:speaker.user_id, name:`${speaker.speaker_name}`}})}>
  
          <AntDesign name="mail" size={28} color="#1E1727" /> 
          </TouchableOpacity> */}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </TouchableOpacity>
        ))}
        {/* <View style={{ alignSelf: 'flex-end',}}>
        <Button style={{marginTop:8,marginBottom:12 ,width:120,borderRadius:15}} color="#00DEA5"
          contentStyle={{ height: 34,  }}
          labelStyle={{ color: "#2F283D", fontSize: 12 }}mode="contained" onPress={() => console.log('Pressed')}>
           View More
          </Button> 
        </View> */}
      </View>
    </ScrollView>
  );
};

export default SpeakersCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  cardsWrapper: {
    marginTop: 20,
    width: "90%",
    alignSelf: "center",
  },
  card: {
    height: 150,
    width: "98%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
    flexDirection: "row",
    shadowColor: "#999",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
    elevation: 5,
    borderWidth: 0.2,
    borderRadius: 8,
  },
  cardImgWrapper: {
    flex: 1,
    //padding:10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  iconWidth: {
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 14,
    width: 55,
    height: 55,
    marginLeft: 10,
    borderRadius: 30,
  },
  cardImg: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    flexDirection: "column",

    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
    borderLeftWidth: 0,
  },
  cardImgWrapper1: {
    flex: 1,
    borderRightWidth: 0,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
  },
  cardImg1: {
    height: "100%",
    width: "100%",
    borderColor: "#fff",
    alignSelf: "center",
    borderRadius: 8,
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderLeftWidth: 0,
  },
  cardText: {
    borderRadius: 8,
  },
  cardInfo: {
    flex: 3,
    padding: 10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
    borderBottomRightRadius: 0,
    borderTopRightRadius: 0,
    borderBottomLeftRadius: 0,
    borderTopLeftRadius: 0,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    lineHeight: 24,
  },
  cardDetails: {
    fontSize: 13,
    // fontWeight:'600',
    color: "#444",
  },
  cardDesg: {
    fontSize: 14,
    fontWeight: "600",
    color: "#444",
    lineHeight: 20,
  },
  attendeeSize: {
    width: 20,
    height: 20,
    marginRight: 15,
  },
  attendeeIcon: {
    marginTop: 8,
    //  marginRight:35
  },
  speakerIcon: {
    marginTop: 10,
    alignSelf: "flex-end",
    paddingRight: 15,
  },
});
