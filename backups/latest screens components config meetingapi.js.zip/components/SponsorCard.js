import React, { useEffect, useState } from "react";
import {
  Alert,
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { useNavigation, useTheme } from "@react-navigation/native";
import { Button } from "react-native-paper";
import IonIcon from "react-native-vector-icons/Ionicons";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import store from "../redux/store";
import Axios from "axios";
import api_url from "../Config/Config";

const SponsorCard = (props) => {
  const theme = useTheme();

  const navigation = useNavigation();

  //console.log("sponsor card props", props);
  // const [Sponsors, setSpeakers] = useState(props.SponsorsData);

  const [SponsorsDta, setSponsors] = useState(props.sponsorsData);
  const [isLoading, setIsLoading] = useState(false);
  //console.log("sponsors data", SponsorsDta);

  // useEffect(()=>{
  //   console.log('sponsors called');
  //   console.log(SponsorsDta)
  //     // console.log(Sponsors)
  // },[])

  // const bookmark = (sponsor)=>{
  //   const formData = new FormData();
  //   formData.append('cookie',store.getState().login.cookie);
  //   formData.append('bookmarktype','products');
  //   formData.append('status',sponsor.bookmarkstatus?0:1);
  //   formData.append('title',sponsor.company);
  //   formData.append('id',sponsor.id);
  //   console.log(sponsor)
  //   Axios.post(`https://ind-backend-events-website.pantheonsite.io/api/user/add_bookmarks`, formData)
  //   .then(res=>{
  //     // console.log(res.data);
  //       if(res.data.status === "ok"){
  //         Alert.alert('Success', res.data.message);
  //           Axios
  //           .post(`https://ind-backend-events-website.pantheonsite.io/api/user/get_sponsors`, formData)
  //           .then(res =>{
  //               setSponsors(res.data.products);
  //           });
  //       }
  //       if(res.data.error){
  //         Alert.alert('Success', res.data.error);
  //       }
  //   })

  // }

  useEffect(() => {
    //console.log(props.sponsorsData);
  }, []);

  const bookmark = (item) => {
    console.log("bookmark data", item);
    setIsLoading(true);
    const formData = new FormData();
    formData.append("cookie", props.login.cookie);
    formData.append("bookmarktype", "sponsors");
    formData.append("status", item.bookmarkstatus ? 0 : 1);
    formData.append("title", item.company_name);
    formData.append("id", item.id);
    formData.append("event_id", props.event.common.event.event_id_single);
    // console.log(exhibitor)

    // formData.append('id',event_id);
    Axios.post(`${api_url.bookmark}`, formData).then((res) => {
      //console.log("bookmark res", res.data);
      if (res.data.status === "ok") {
        Alert.alert("Success", res.data.message);
        Axios.post(`${api_url.sponsorsList}`, formData).then((res) => {
          // console.log("sponsors list", res);
          setSponsors(res.data.sponsors_list);
        });
      }
      if (res.data.error) {
        Alert.alert("Success", res.data.error);
      }
    });
  };

  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle={theme.dark ? "light-content" : "dark-content"} />

      <View style={styles.cardsWrapper}>
        <Text style={styles.stitle}>Platinum Sponsors :</Text>
        {SponsorsDta.Platinum ? (
          SponsorsDta.Platinum.map((platinum, i) => (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("SponsorDetail", { id: platinum.id })
              }
              //style={styles.scardinfo}
              key={i}
            >
              <View style={styles.card}>
                <View style={styles.cardInfo}>
                  <View style={styles.clientlogo}>
                    <Image
                      source={{ uri: platinum.SponsorLogo }}
                      resizeMode="contain"
                      style={styles.iconWidth}
                    />
                  </View>

                  <TouchableOpacity
                    onPress={() => navigation.navigate("SponsorDetail", { id: platinum.id })}
                  >
                    <Text style={styles.cardTitle}>{platinum.sponsorname}</Text>

                    <Text numberOfLines={3} style={styles.cardDetails}>
                      {platinum.SponsorBio}
                    </Text>
                    {/* <Text style={[styles.cardDetails, { marginTop: 10 }]}>
                      <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                        Classification :
                      </Text>{" "}
                    </Text> */}
                    <Text style={styles.cardDetails}></Text>
                    <View style={{ flex: 1, flexDirection: "row" }}>
                      <View style={{ flex: 1, flexDirection: "column" }}>
                        <Text style={styles.cardDetails}>
                          <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                            Country :
                          </Text>{" "}
                        </Text>
                        <Text style={styles.cardDetails}>
                          {platinum.country}
                        </Text>
                      </View>

                      <TouchableOpacity style={{ alignSelf: "flex-end" }}>
                        <View style={styles.favorite}>
                          <MaterialIcons
                            onPress={() => bookmark(platinum)}
                            style={styles.favoiteIcon}
                            name={
                              platinum.bookmarkstatus
                                ? "favorite"
                                : "favorite-border"
                            }
                            size={30}
                            color="#000"
                          />
                          {/* <Text style={{ textAlign: "center", fontSize: 11 }}>
                            Favourite
                          </Text> */}
                        </View>
                      </TouchableOpacity>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          ))
        ) : (
          <Text></Text>
        )}
      </View>

      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Gold Sponsors : </Text>
        </View>

        <View>
          {SponsorsDta.Gold ? (
            SponsorsDta.Gold.map((gold, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: gold.id })
                }
                //style={styles.scardinfo}
                key={i}
              >
                <View style={styles.card}>
                  <View style={styles.cardInfo}>
                    <View style={styles.clientlogo}>
                      <Image
                        source={{ uri: gold.SponsorLogo }}
                        resizeMode="contain"
                        style={styles.iconWidth}
                      />
                    </View>

                    <Text style={styles.cardTitle}>{gold.sponsorname}</Text>

                    <Text numberOfLines={2} style={styles.cardDetails}>
                      {gold.SponsorBio}
                    </Text>
                    <Text style={[styles.cardDetails, { marginTop: 10 }]}>
                      <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                        Classification :
                      </Text>{" "}
                    </Text>
                    <Text style={styles.cardDetails}></Text>
                    <View style={{ flex: 1, flexDirection: "row" }}>
                      <View style={{ flex: 1, flexDirection: "column" }}>
                        <Text style={styles.cardDetails}>
                          <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                            Country :
                          </Text>{" "}
                        </Text>
                        <Text style={styles.cardDetails}>{gold.country}</Text>
                      </View>

                      <TouchableOpacity style={{ alignSelf: "flex-end" }}>
                        <View style={styles.favorite}>
                          <MaterialIcons
                            onPress={() => bookmark(gold)}
                            style={styles.favoiteIcon}
                            name={
                              gold.bookmarkstatus
                                ? "favorite"
                                : "favorite-border"
                            }
                            size={30}
                            color="#000"
                          />
                          {/* <Text style={{ textAlign: "center", fontSize: 11 }}>
                        Favourite
                      </Text> */}
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>

      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Silver Sponsors : </Text>
        </View>

        <View>
          {SponsorsDta.Silver ? (
            SponsorsDta.Silver.map((silver, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: silver.id })
                }
                //style={styles.scardinfo}
                key={i}
              >
                <View style={styles.card}>
                  <View style={styles.cardInfo}>
                    <View style={styles.clientlogo}>
                      <Image
                        source={{ uri: silver.SponsorLogo }}
                        resizeMode="contain"
                        style={styles.iconWidth}
                      />
                    </View>

                    <Text style={styles.cardTitle}>{silver.sponsorname}</Text>

                    <Text numberOfLines={2} style={styles.cardDetails}>
                      {silver.SponsorBio}
                    </Text>
                    <Text style={[styles.cardDetails, { marginTop: 10 }]}>
                      <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                        Classification :
                      </Text>{" "}
                    </Text>
                    <Text style={styles.cardDetails}></Text>
                    <View style={{ flex: 1, flexDirection: "row" }}>
                      <View style={{ flex: 1, flexDirection: "column" }}>
                        <Text style={styles.cardDetails}>
                          <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                            Country :
                          </Text>{" "}
                        </Text>
                        <Text style={styles.cardDetails}>{silver.country}</Text>
                      </View>

                      <TouchableOpacity style={{ alignSelf: "flex-end" }}>
                        <View style={styles.favorite}>
                          <MaterialIcons
                            onPress={() => bookmark(silver)}
                            style={styles.favoiteIcon}
                            name={
                              silver.bookmarkstatus
                                ? "favorite"
                                : "favorite-border"
                            }
                            size={30}
                            color="#000"
                          />
                          {/* <Text style={{ textAlign: "center", fontSize: 11 }}>
                        Favourite
                      </Text> */}
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>

      <View style={styles.cardsWrapper}>
        <View>
          <Text style={styles.stitle}>Bronze Sponsors : </Text>
        </View>

        <View>
          {SponsorsDta.Bronze ? (
            SponsorsDta.Bronze.map((bronze, i) => (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("SponsorDetail", { id: bronze.id })
                }
                //style={styles.scardinfo}
                key={i}
              >
                <View style={styles.card}>
                  <View style={styles.cardInfo}>
                    <View style={styles.clientlogo}>
                      <Image
                        source={{ uri: bronze.SponsorLogo }}
                        resizeMode="contain"
                        style={styles.iconWidth}
                      />
                    </View>

                    <Text style={styles.cardTitle}>{bronze.sponsorname}</Text>

                    <Text numberOfLines={2} style={styles.cardDetails}>
                      {bronze.SponsorBio}
                    </Text>
                    <Text style={[styles.cardDetails, { marginTop: 10 }]}>
                      <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                        Classification :
                      </Text>{" "}
                    </Text>
                    <Text style={styles.cardDetails}></Text>
                    <View style={{ flex: 1, flexDirection: "row" }}>
                      <View style={{ flex: 1, flexDirection: "column" }}>
                        <Text style={styles.cardDetails}>
                          <Text style={{ fontWeight: "bold", lineHeight: 18 }}>
                            Country :
                          </Text>{" "}
                        </Text>
                        <Text style={styles.cardDetails}>{bronze.country}</Text>
                      </View>

                      <TouchableOpacity style={{ alignSelf: "flex-end" }}>
                        <View style={styles.favorite}>
                          <MaterialIcons
                            onPress={() => bookmark(bronze)}
                            style={styles.favoiteIcon}
                            name={
                              bronze.bookmarkstatus
                                ? "favorite"
                                : "favorite-border"
                            }
                            size={30}
                            color="#000"
                          />
                          {/* <Text style={{ textAlign: "center", fontSize: 11 }}>
                        Favourite
                      </Text> */}
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <Text></Text>
          )}
        </View>
      </View>
    </ScrollView>
  );
};

export default SponsorCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  stitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#05CB9A",
    alignSelf: "center",
    padding: 5,
    lineHeight: 25,
  },
  scardinfo: {
    height: 100,
    width: "50%",
    backgroundColor: "#fff",
  },
  scard: {
    flex: 1,
    //width:"98%",
    marginTop: 20,
    flexDirection: "row",
    flexWrap: "wrap",
  },
  attendeeBtn1: {},
  cardsWrapper: {
    marginTop: 20,
    width: "98%",
    alignSelf: "center",
  },
  card: {
    width: "90%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
    flexDirection: "row",
    shadowColor: "#999",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
    elevation: 5,
    borderWidth: 0.7,
    borderColor: "#ddd",
    borderRadius: 8,
  },
  cardInfo: {
    flex: 1,
    //padding: 10,
    borderColor: "#fff",
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderRadius: 8,
    backgroundColor: "#fff",
  },
  iconWidth: {
    alignSelf: "center",
    margin: 10,
    // justifyContent:'center',
    // marginTop:14,
    marginBottom: 10,
    width: 300,
    height: 35,
    //marginLeft:10,
    //borderRadius:30
  },
  cardTitle: {
    paddingHorizontal: 10,
    fontSize: 18,
    fontWeight: "bold",
    lineHeight: 34,
    color: "#05CB9A",
  },
  cardDetails: {
    paddingHorizontal: 10,
    fontSize: 13,
    // fontWeight:'600',
    color: "#444",
    marginBottom: 3,
  },
  favorite: {
    alignSelf: "flex-end",
    height: 70,
    width: 70,
    borderColor: "#ddd",
    borderWidth: 0.7,
    borderBottomWidth: 0,
    borderRightWidth: 0,
  },
  favoiteIcon: {
    marginTop: 15,
    alignSelf: "center",
    justifyContent: "center",
    alignItems: "center",
  },
  card1: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    height: 200,
    width: "100%",
    alignSelf: "center",
    justifyContent: "center",
    marginVertical: 10,
  },

  attendeeSize: {
    width: 200,
    height: 45,
    maxWidth: "100%",
    // marginRight:15,
    // flex:1,
  },
});
